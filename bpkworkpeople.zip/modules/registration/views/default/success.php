<div class="registration registration--2">
    <div class="container">
        <div class="row">
            <div class="registration__main col">
                <div class="registration__inner">
                        <div class="registration__title">
                            Вы успешно зарегистрировались
                        </div>
                        <br>
                        <div class="registration__form">
                        <?= Yii::t('main', 'To complete registration, please confirm your email.') ?>
                            <div class="registration__submit">
                                <div>
                                    
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>