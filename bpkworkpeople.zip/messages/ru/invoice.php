<?php 

return [
	"Invoices"=>"Счета",
	"Deposit"=>"Пополнить",
	"Make Deposit"=>"Сформировать Счёт",
	"Amount"=>"Сумма",
	"Status"=>"Статус",
	"Go To Payment Site"=>"Перейти На Сайт Оплаты",
	"Pay"=>"Оплатить",
	"View"=>"Просмотр",
	"Payment was successful, funds are credited to your account balance."=>"Оплата прошла успешно, средства зачислены на баланс вашего аккаунта.",
	"Waitng for payment."=>"Ожидание оплаты.",
	"Pay System"=>"Платёжный агрегатор",
	"Price"=>"Сумма",
	"Currency Code"=>"Валюта",
	"Pay Date"=>"Дата оплаты",
	"Created At"=>"Дата",
	"Actions"=>"Действия",
];
