<?php 

return [
	"Ukraine"=>"Украина",
	"Tajikistan"=>"Таджикистан",
	"Russia"=>"Россия",
	"Uzbekistan"=>"Узбекистан",
	"Belarus"=>"Беларусь",
	"Hungary"=>"Венгрия",
	"Moldova"=>"Молдова",
	"Romania"=>"Румыния",
	"Georgia"=>"Грузия",
	"Azerbaijan"=>"Азербайджан",
	"Kazakhstan"=>"Казахстан",
	"Poland"=>"Польша",
	"Slovakia"=>"Словакия",
	"Israel"=>"Израиль",
	"Germany"=>"Германия",
	"Netherlands"=>"Нидерланды",
	"Norway"=>"Норвегия",
	"Czech"=>"Чехия",
];
