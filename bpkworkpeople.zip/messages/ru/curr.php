<?php 

return [
	"UAH"=>"ГРН",
	"Ukrainian"=>"Ukrainian hryvnia",
	"RUR"=>"РУБ",
	"Russian ruble"=>"Российский рубль",
	"U.S. dollar"=>"Доллар США",
	"Euro"=>"Евро",
	"Czech crown"=>"Чешская корона",
	"Ukrainian hryvnia"=>"Украинская гривна",
	"Polish złoty"=>"Польский злотый",
	"Hungarian forint"=>"Венгерский форинт",
];
