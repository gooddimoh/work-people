<?php 

return [
	"Localization list"=>"Список локализаций",
	"Category list"=>"Список категорий",
	"Category job"=>"Список профессий",
	"Country list"=>"Список стран",
	"Category main page list"=>"Категории на главной странице",
	"Country city list"=>"Список городов стран",
	"Documents required"=>"Необходимые документы",
	"Type of working shift"=>"График работы",
	"Language list"=>"Список языков",
	"Employment list"=>"Тип работы",
	"Vacancy"=>"Вакансии",
];
