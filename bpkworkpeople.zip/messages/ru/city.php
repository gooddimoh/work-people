<?php 

return [
	"Moscow"=>"Москва",
	"Saint Petersburg"=>"Санкт-Петербург",
	"Vladivostok"=>"Владивосток",
	"Kiev"=>"Киев",
	"Lviv"=>"Львов",
	"Dushanbe"=>"Душанбе",
	"Praha"=>"Прага",
	"Zaporizhia"=>"Запорожье",
	"Kharkiv"=>"Харьков",
];
