<?php 

return [
	"Ukrainian"=>"Украинский",
	"Russian"=>"Русский",
	"English"=>"Английский",
	"Polish"=>"Польский",
	"Deutsch"=>"Немецкий",
];
