<?php 

return [
	"Auto Mails"=>"Автоматическая рассылка подходящих вакансий",
	"Request"=>"Запрос",
	"Location"=>"Город",
	"Create Auto Mail"=>"Добавить автоматическую рассылку",
	"Created At"=>"Добавлено",
	"User ID"=>"ID пользователя",
	"Category ID"=>"ID категории",
	"Update Auto Mail"=>"Редактировать автоматическую рассылку ",
];
