<?php 

return [
	"Moscow"=>"Москва",
	"Saint Petersburg"=>"Санкт-Петербург",
	"Vladivostok"=>"Владивосток",
	"Kiev"=>"Київ",
	"Lviv"=>"Львів",
	"Dushanbe"=>"Душанбе",
	"Praha"=>"Прага",
	"Zaporizhia"=>"Запорі́жжя",
	"Kharkiv"=>"Ха́рків",
];
