<?php 

return [
	"UAH"=>"UAH",
	"Ukrainian"=>"Ukrainian hryvnia",
	"RUR"=>"RUR",
	"Russian ruble"=>"Russian ruble",
	"U.S. dollar"=>"U.S. dollar",
	"Euro"=>"Euro",
	"Czech crown"=>"Czech crown",
	"Ukrainian hryvnia"=>"Ukrainian hryvnia",
	"Polish złoty"=>"Polish złoty",
	"Hungarian forint"=>"Hungarian forint",
];
