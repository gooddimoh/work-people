<?php 

return [
	"Moscow"=>"Moscow",
	"Saint Petersburg"=>"Saint Petersburg",
	"Vladivostok"=>"Vladivostok",
	"Kiev"=>"Kiev",
	"Lviv"=>"Lviv",
	"Dushanbe"=>"Dushanbe",
	"Praha"=>"Praha",
	"Zaporizhia"=>"Zaporizhia",
	"Kharkiv"=>"Kharkiv",
];
