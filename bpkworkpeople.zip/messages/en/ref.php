<?php 

return [
	"Localization list"=>"Localization list",
	"Category list"=>"Category list",
	"Category job"=>"Category job",
	"Country list"=>"Country list",
	"Category main page list"=>"Категории на главной странице",
	"Country city list"=>"Country city list",
	"Documents required"=>"Documents required",
	"Type of working shift"=>"Type of working shift",
	"Language list"=>"Language list",
	"Employment list"=>"Employment list",
	"Vacancy"=>"Vacancy",
];
