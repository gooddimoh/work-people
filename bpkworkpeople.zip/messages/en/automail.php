<?php 

return [
	"Auto Mails"=>"Auto Mails",
	"Request"=>"Request",
	"Location"=>"Location",
	"Create Auto Mail"=>"Create Auto Mail",
	"Created At"=>"Created At",
	"User ID"=>"User ID",
	"Category ID"=>"Category ID",
	"Update Auto Mail"=>"Update Auto Mail",
];
