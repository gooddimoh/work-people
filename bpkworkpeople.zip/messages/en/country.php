<?php 

return [
	"Ukraine"=>"Ukraine",
	"Tajikistan"=>"Tajikistan",
	"Russia"=>"Russia",
	"Uzbekistan"=>"Uzbekistan",
	"Belarus"=>"Belarus",
	"Hungary"=>"Hungary",
	"Moldova"=>"Moldova",
	"Romania"=>"Romania",
	"Georgia"=>"Georgia",
	"Azerbaijan"=>"Azerbaijan",
	"Kazakhstan"=>"Kazakhstan",
	"Poland"=>"Poland",
	"Slovakia"=>"Slovakia",
	"Israel"=>"Israel",
	"Germany"=>"Germany",
	"Netherlands"=>"Netherlands",
	"Norway"=>"Norway",
	"Czech"=>"Czech",
];
