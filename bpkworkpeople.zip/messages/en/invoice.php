<?php 

return [
	"Invoices"=>"Счета",
	"Deposit"=>"Deposit",
	"Make Deposit"=>"Make Deposit",
	"Amount"=>"Amount",
	"Status"=>"Status",
	"Go To Payment Site"=>"Go To Payment Site",
	"Pay"=>"Pay",
	"View"=>"View",
	"Payment was successful, funds are credited to your account balance."=>"Payment was successful, funds are credited to your account balance.",
	"Waitng for payment."=>"Waitng for payment.",
	"Pay System"=>"Pay System",
	"Price"=>"Price",
	"Currency Code"=>"Currency",
	"Pay Date"=>"Pay Date",
	"Created At"=>"Created At",
	"Actions"=>"Actions",
];
