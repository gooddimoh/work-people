<?php 

return [
	"Ukrainian"=>"Ukrainian",
	"Russian"=>"Russian",
	"English"=>"English",
	"Polish"=>"Polish",
	"Deutsch"=>"Deutsch",
];
