<?php
/* {title}public_offer{/title} */
$this->title = 'public_offer';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
<div class="container">
<div class="container">
<h2>Wws work</h2>

<p>public_offer.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</div>
</div>
</div>
