<?php
/* {title}site_map{/title} */
$this->title = 'site_map';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
<div class="container">
<div class="container">
<h2>Wws work</h2>

<p>site_map.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</div>
</div>
</div>
