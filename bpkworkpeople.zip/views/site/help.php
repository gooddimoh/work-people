<?php
/* {title}Помощь{/title} */
$this->title = 'Помощь';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-help">
<div class="container">
<h1>Помощь</h1>

<p>This is the Help page.</p>
</div>
</div>
