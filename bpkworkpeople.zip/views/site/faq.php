<?php
/* {title}О нас{/title} */
$this->title = 'О нас';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
<div class="container">
<div class="container">
<h2>Wws work</h2>

<p>About.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</div>
</div>
</div>
